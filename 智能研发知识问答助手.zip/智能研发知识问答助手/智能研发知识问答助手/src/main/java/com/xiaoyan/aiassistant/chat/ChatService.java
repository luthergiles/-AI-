package com.xiaoyan.aiassistant.chat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xiaoyan.aiassistant.entity.PlatformReference;
import com.xiaoyan.aiassistant.memory.ConversationMemory;
import com.xiaoyan.aiassistant.memory.ShortTermMemoryService;
import com.xiaoyan.aiassistant.retrieval.HybridRetrievalService;
import com.xiaoyan.aiassistant.retrieval.RetrievalCandidate;
import com.xiaoyan.aiassistant.service.ExpandSearchSwitchService;
import com.xiaoyan.aiassistant.service.PlatformSearchStrategy;
import dev.langchain4j.model.chat.StreamingChatModel;
import dev.langchain4j.model.chat.response.ChatResponse;
import dev.langchain4j.model.chat.response.StreamingChatResponseHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.Map;

// 负责在线问答主链路编排。
@Slf4j
@Service
@RequiredArgsConstructor
public class ChatService {
    private static final String DEFAULT_USER_ID = "default";
    private static final String META_PREFIX = "__META__:";

    private final ShortTermMemoryService shortTermMemoryService;
    private final QueryRewriteService queryRewriteService;
    private final HybridRetrievalService retrievalService;
    private final PromptBuilder promptBuilder;
    private final StreamingChatModel streamingChatModel;
    private final ExpandSearchSwitchService expandSearchSwitchService;
    private final PlatformSearchStrategy platformSearchService;
    private final ObjectMapper objectMapper;

    // 在线问答主流程：记忆读取、Query 重写、RAG 检索、流式生成、记忆更新。
    public Flux<String> stream(ChatRequest request) {
        String userId = normalizeUserId(request.userId());
        String sessionId = StringUtils.hasText(request.sessionId()) ? request.sessionId() : "default";
        String memorySessionId = userId + ":" + sessionId;
        String message = request.message();
        // 开关以 Redis 保存的状态为准；Redis 读不到时退回请求体携带的前端状态。
        boolean expandEnable = resolveExpandEnable(userId, request.expandSearch());
        // useRag 为 false 时跳过知识库检索，直接大模型问答。
        boolean useRag = request.useRag() == null || request.useRag();
        return Flux.create(sink -> {
            ConversationMemory memory = shortTermMemoryService.get(memorySessionId);
            QueryRewriteResult rewrite = queryRewriteService.rewrite(message, memory);
            List<RetrievalCandidate> longMemories = List.of();
            List<RetrievalCandidate> knowledge = List.of();
            if (useRag) {
                List<String> semanticQueries = rewrite.semanticQueries(message);
                longMemories = retrievalService.retrieveLongMemory(userId, semanticQueries);
                knowledge = retrievalService.retrieveKnowledge(semanticQueries, rewrite.keywordText(message));
            }
            String prompt = promptBuilder.build(message, rewrite, memory, longMemories, knowledge);
            StringBuilder answer = new StringBuilder();
            streamingChatModel.chat(prompt, new StreamingChatResponseHandler() {
                // 收到流式片段后立即推给前端。
                @Override
                public void onPartialResponse(String partialResponse) {
                    answer.append(partialResponse);
                    sink.next(partialResponse);
                }

                // 完整回答结束后写入短期记忆；开关开启时附带拓展检索结果。
                @Override
                public void onCompleteResponse(ChatResponse completeResponse) {
                    shortTermMemoryService.append(memorySessionId, message, answer.toString());
                    if (expandEnable) {
                        sink.next(buildExpandMeta(message, answer.toString()));
                    }
                    sink.complete();
                }

                // 模型调用异常时交给响应流向前端暴露。
                @Override
                public void onError(Throwable error) {
                    sink.error(error);
                }
            });
        });
    }

    // 场景3/5：拓展检索任何异常都不阻断主回答，出错时返回空资料。
    private String buildExpandMeta(String question, String answer) {
        List<PlatformReference> refList;
        int extraToken = 0;
        try {
            refList = platformSearchService.searchByKeyword(question);
            extraToken = estimateExtraToken(question, answer);
        } catch (Exception ex) {
            log.warn("Expand search failed, fallback to empty references", ex);
            refList = List.of();
            extraToken = 0;
        }
        try {
            Map<String, Object> meta = Map.of(
                    "references", refList,
                    "extraToken", extraToken);
            return META_PREFIX + objectMapper.writeValueAsString(meta);
        } catch (Exception ex) {
            log.warn("Failed to serialize expand search meta", ex);
            return META_PREFIX + "{\"references\":[],\"extraToken\":0}";
        }
    }

    // 实训模拟：额外 token 消耗 = 问题文本 + 检索资料文本的估算值。
    private int estimateExtraToken(String question, String answer) {
        return Math.max(100, (question.length() + answer.length()) * 2);
    }

    // 场景4：开关关闭时完全不执行检索逻辑；以 Redis 保存的状态为准，Redis 不可用时退回前端请求体携带的开关。
    private boolean resolveExpandEnable(String userId, Boolean requestFlag) {
        Boolean redisValue = expandSearchSwitchService.readEnabled(userId);
        if (redisValue != null) {
            return redisValue;
        }
        return Boolean.TRUE.equals(requestFlag);
    }

    // 空用户统一归入 default，避免 Redis key 和长期记忆过滤出现空值。
    private String normalizeUserId(String userId) {
        return StringUtils.hasText(userId) ? userId.trim() : DEFAULT_USER_ID;
    }
}
