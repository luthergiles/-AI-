package com.xiaoyan.aiassistant.dto;

import com.xiaoyan.aiassistant.entity.PlatformReference;
import java.util.List;

/**
 * 流式聊天接口返回给前端的DTO
 * 返回AI回答内容、本地知识库参考片段、拓展检索三方平台资料、额外token消耗
 */
public class StreamChatResp {

    /**
     * AI大模型生成的回答文本
     */
    private String answer;

    /**
     * 本地知识库RAG返回的参考文档片段
     */
    private List<String> localReferences;

    /**
     * 拓展检索结果：抖音、B站、CSDN平台参考资料列表
     * expandSearch开启才会有数据；为空时前端展示“暂未查询到相关平台参考内容”
     */
    private List<PlatformReference> platformReferences;

    /**
     * 拓展检索带来额外消耗的token数量，实训模拟数值
     */
    private Integer extraToken;


    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public List<String> getLocalReferences() {
        return localReferences;
    }

    public void setLocalReferences(List<String> localReferences) {
        this.localReferences = localReferences;
    }

    public List<PlatformReference> getPlatformReferences() {
        return platformReferences;
    }

    public void setPlatformReferences(List<PlatformReference> platformReferences) {
        this.platformReferences = platformReferences;
    }

    public Integer getExtraToken() {
        return extraToken;
    }

    public void setExtraToken(Integer extraToken) {
        this.extraToken = extraToken;
    }
}
