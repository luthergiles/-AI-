package com.xiaoyan.aiassistant.entity;

import lombok.Data;

/**
 * 拓展检索 - 三方平台参考资料实体
 * 用于存放模拟检索抖音、B站、CSDN返回的数据
 * 实训要求：只返回标题、链接，抖音/B站不需要抓取视频内容；CSDN附带摘要
 */
@Data
public class PlatformReference {

    /**
     * 平台标识
     * 可选值：douyin(抖音) / bilibili(B站) / csdn
     */
    private String platform;

    /**
     * 检索结果标题
     */
    private String title;

    /**
     * 内容摘要
     * 规则：抖音、b站摘要填空字符串；CSDN存放文章简短摘要
     */
    private String summary;

    /**
     * 跳转链接，直接给到前端，用户点击跳转到对应平台
     * 本项目只是返回链接，不去爬取链接里面的网页内容，符合文档禁止逆向爬虫的要求
     */
    private String url;

}
