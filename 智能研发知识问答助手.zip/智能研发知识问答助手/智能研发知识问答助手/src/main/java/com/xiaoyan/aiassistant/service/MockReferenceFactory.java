package com.xiaoyan.aiassistant.service;

import com.xiaoyan.aiassistant.entity.PlatformReference;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

// 真实抓取失败时退回平台搜索入口，保证拓展资料区域不为空。
final class MockReferenceFactory {

    private MockReferenceFactory() {
    }

    static List<PlatformReference> build(String keyword) {
        String text = keyword == null ? "" : keyword.trim();
        String query = URLEncoder.encode(text, StandardCharsets.UTF_8);
        List<PlatformReference> list = new ArrayList<>();
        list.add(build("douyin", "抖音 · 「" + text + "」短视频讲解", "",
            "https://www.douyin.com/search/" + query + "?type=general"));
        list.add(build("bilibili", "B站 · 「" + text + "」教学视频合集", "",
            "https://search.bilibili.com/video?keyword=" + query));
        list.add(build("csdn", "CSDN · 「" + text + "」技术文章与解决方案",
            "进入搜索结果页后可查看围绕该关键词的技术文章与实战教程。",
            "https://so.csdn.net/so/search?q=" + query + "&t=all"));
        list.add(build("web", "全网搜索 · 「" + text + "」相关资料",
            "若以上平台结果为空，可通过该入口查看搜索引擎汇总的公开内容。",
            "https://www.bing.com/search?q=" + query));
        return list;
    }

    private static PlatformReference build(String platform, String title, String summary, String url) {
        PlatformReference ref = new PlatformReference();
        ref.setPlatform(platform);
        ref.setTitle(title);
        ref.setSummary(summary);
        ref.setUrl(url);
        return ref;
    }
}
