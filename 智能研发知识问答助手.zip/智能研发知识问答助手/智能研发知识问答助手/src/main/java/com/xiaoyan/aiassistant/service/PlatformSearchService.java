package com.xiaoyan.aiassistant.service;

import com.xiaoyan.aiassistant.entity.PlatformReference;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * 拓展检索模拟服务（默认启用，合规）
 * 不抓取网页正文，只生成平台搜索结果页跳转链接，用户点击后由平台展示真实内容。
 */
@Service
@ConditionalOnProperty(name = "app.expand-search.mode", havingValue = "mock", matchIfMissing = true)
public class PlatformSearchService implements PlatformSearchStrategy {

    @Override
    public List<PlatformReference> searchByKeyword(String keyword) {
        return MockReferenceFactory.build(keyword);
    }
}
