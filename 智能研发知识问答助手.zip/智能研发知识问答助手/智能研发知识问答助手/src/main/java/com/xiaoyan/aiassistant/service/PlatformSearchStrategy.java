package com.xiaoyan.aiassistant.service;

import com.xiaoyan.aiassistant.entity.PlatformReference;
import java.util.List;

// 拓展检索策略接口，模拟模式与真实抓取模式可配置切换。
public interface PlatformSearchStrategy {
    List<PlatformReference> searchByKeyword(String keyword);
}
