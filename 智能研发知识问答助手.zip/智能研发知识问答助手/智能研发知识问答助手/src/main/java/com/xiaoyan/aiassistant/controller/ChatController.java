package com.xiaoyan.aiassistant.controller;

import com.xiaoyan.aiassistant.chat.ChatRequest;
import com.xiaoyan.aiassistant.chat.ChatService;
import com.xiaoyan.aiassistant.service.ExpandSearchSwitchService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

import java.util.Map;

// 在线问答流式接口。
@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatController {
    private final ChatService chatService;
    private final ExpandSearchSwitchService expandSearchSwitchService;

    // 以 SSE 形式流式返回回答内容。
    @PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE + ";charset=UTF-8")
    public Flux<String> stream(@RequestBody ChatRequest request) {
        return chatService.stream(request);
    }

    // 场景1/2：更新用户拓展检索开关状态并写入 Redis。
    @PostMapping("/expand-switch")
    public Map<String, Object> updateExpandSwitch(@RequestBody Map<String, Object> body) {
        String userId = String.valueOf(body.getOrDefault("userId", "default"));
        boolean enabled = Boolean.parseBoolean(String.valueOf(body.get("enabled")));
        expandSearchSwitchService.setEnabled(userId, enabled);
        return Map.of("success", true, "enabled", enabled);
    }

    // 查询用户当前开关状态，页面刷新后同步。
    @GetMapping("/expand-switch")
    public Map<String, Object> getExpandSwitch(@RequestParam(required = false) String userId) {
        return Map.of("enabled", expandSearchSwitchService.isEnabled(userId));
    }
}
