package com.xiaoyan.aiassistant.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

// 拓展检索开关状态存储：按用户隔离，保存在 Redis 中。
@Slf4j
@Service
@RequiredArgsConstructor
public class ExpandSearchSwitchService {
    private static final String KEY_PREFIX = "xiaoyan:expand-switch:";

    private final StringRedisTemplate redisTemplate;

    // 读取用户开关状态，Redis 异常时默认关闭，不影响主流程。
    public boolean isEnabled(String userId) {
        return Boolean.TRUE.equals(readEnabled(userId));
    }

    // 读取开关原始状态：Redis 有值返回 true/false，Redis 不可用返回 null，交由上层决定兜底策略。
    public Boolean readEnabled(String userId) {
        try {
            String value = redisTemplate.opsForValue().get(key(userId));
            return value != null && Boolean.parseBoolean(value);
        } catch (RuntimeException ex) {
            log.warn("Failed to read expand search switch for user {}", userId, ex);
            return null;
        }
    }

    // 保存用户开关状态（true 开启 / false 关闭）。
    public void setEnabled(String userId, boolean enabled) {
        redisTemplate.opsForValue().set(key(userId), String.valueOf(enabled));
    }

    // 生成 Redis key，空用户归入 default。
    private String key(String userId) {
        String normalized = (userId == null || userId.isBlank()) ? "default" : userId.trim();
        return KEY_PREFIX + normalized;
    }
}
