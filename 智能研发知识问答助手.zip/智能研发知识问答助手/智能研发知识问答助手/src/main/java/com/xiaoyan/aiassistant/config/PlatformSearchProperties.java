package com.xiaoyan.aiassistant.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

// 拓展检索模块配置。
@Data
@Component
@ConfigurationProperties(prefix = "app.expand-search")
public class PlatformSearchProperties {
    /** mock=模拟入口(合规) / remote=调用 Python 自动化抓取(违反实训约束) */
    private String mode = "mock";
    private String remoteBaseUrl = "http://127.0.0.1:8000";
    private int connectTimeoutMs = 1500;
    private int readTimeoutMs = 15000;
}
