package com.xiaoyan.aiassistant.chat;

// 聊天请求体，包含用户、会话、本轮问题，以及拓展检索开关和 RAG 开关。
public record ChatRequest(String userId, String sessionId, String message,
                          Boolean expandSearch, Boolean useRag) {
}

