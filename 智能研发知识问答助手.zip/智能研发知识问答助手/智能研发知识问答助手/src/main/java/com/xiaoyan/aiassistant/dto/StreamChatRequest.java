package com.xiaoyan.aiassistant.dto;

public class StreamChatRequest {
    private final String message;
    private final String sessionId;
    private final Boolean useRag;

    public StreamChatRequest(String message, String sessionId, Boolean useRag) {
        this.message = message;
        this.sessionId = sessionId;
        this.useRag = useRag;
    }

    public String getMessage() {
        return message;
    }

    public String getSessionId() {
        return sessionId;
    }

    public Boolean getUseRag() {
        return useRag;
    }
}
