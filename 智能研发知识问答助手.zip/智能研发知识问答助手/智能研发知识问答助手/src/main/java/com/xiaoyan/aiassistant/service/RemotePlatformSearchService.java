package com.xiaoyan.aiassistant.service;

import com.xiaoyan.aiassistant.config.PlatformSearchProperties;
import com.xiaoyan.aiassistant.entity.PlatformReference;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 拓展检索真实抓取实现
 * 调用 Python(Playwright) 自动化搜索服务获取三方平台真实结果。
 * 该实现属于网页抓取，与实训「禁止爬虫」约束冲突，仅在 app.expand-search.mode=remote 时启用。
 * 任何异常都降级为模拟搜索入口，保证 AI 主回答不受影响。
 */
@Slf4j
@Service
@ConditionalOnProperty(name = "app.expand-search.mode", havingValue = "remote")
public class RemotePlatformSearchService implements PlatformSearchStrategy {

    private final RestTemplate restTemplate;
    private final String baseUrl;

    public RemotePlatformSearchService(RestTemplateBuilder builder, PlatformSearchProperties properties) {
        this.baseUrl = properties.getRemoteBaseUrl();
        this.restTemplate = builder
            .connectTimeout(Duration.ofMillis(properties.getConnectTimeoutMs()))
            .readTimeout(Duration.ofMillis(properties.getReadTimeoutMs()))
            .build();
    }

    @Override
    public List<PlatformReference> searchByKeyword(String keyword) {
        try {
            String url = UriComponentsBuilder.fromHttpUrl(baseUrl + "/search")
                .queryParam("keyword", keyword)
                .toUriString();
            Map<String, Object> body = restTemplate.exchange(
                url, HttpMethod.GET, null,
                new ParameterizedTypeReference<Map<String, Object>>() {}).getBody();
            List<PlatformReference> parsed = parse(body);
            if (!parsed.isEmpty()) {
                return parsed;
            }
            log.warn("Remote expand search returned empty for keyword [{}], fallback to mock entries", keyword);
            return MockReferenceFactory.build(keyword);
        } catch (Exception ex) {
            log.warn("Remote expand search failed for keyword [{}]: {}", keyword, ex.getMessage());
            return MockReferenceFactory.build(keyword);
        }
    }

    // 把 Python 返回的 JSON 列表转换成实体。
    @SuppressWarnings("unchecked")
    private List<PlatformReference> parse(Map<String, Object> body) {
        List<PlatformReference> result = new ArrayList<>();
        if (body == null || !(body.get("references") instanceof List)) {
            return result;
        }
        for (Object item : (List<Object>) body.get("references")) {
            if (!(item instanceof Map)) {
                continue;
            }
            Map<String, Object> map = (Map<String, Object>) item;
            PlatformReference ref = new PlatformReference();
            ref.setPlatform(asText(map.get("platform")));
            ref.setTitle(asText(map.get("title")));
            ref.setSummary(asText(map.get("summary")));
            ref.setUrl(asText(map.get("url")));
            if (!ref.getUrl().isBlank() && !ref.getTitle().isBlank()) {
                result.add(ref);
            }
        }
        return result;
    }

    private String asText(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
