"""
拓展检索自动化服务（抖音 / B站 / CSDN）
用 Playwright 无头浏览器代替用户执行搜索，抽取真实结果的标题、摘要、链接后返回。

风险提示：本实现属于网页抓取，与实训需求「禁止爬虫」条款冲突，
默认不在 Java 侧启用，仅当 app.expand-search.mode=remote 时才会被调用。
"""

import asyncio
import re
from urllib.parse import quote

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from playwright.async_api import async_playwright

app = FastAPI(title="expand-search-svc")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")

TIMEOUT_MS = 12000
MAX_ITEMS = 3


def clean(text: str) -> str:
    """去掉零宽字符和多余空白，B站标题里带高亮标记。"""
    if not text:
        return ""
    text = re.sub(r"[\u200b-\u200f\ufeff]", "", text)
    return re.sub(r"\s+", " ", text).strip()


async def new_page(browser):
    context = await browser.new_context(user_agent=UA, viewport={"width": 1366, "height": 768},
                                        locale="zh-CN")
    return context, await context.new_page()


async def search_bilibili(keyword: str, browser):
    context, page = await new_page(browser)
    try:
        url = f"https://search.bilibili.com/all?keyword={quote(keyword)}"
        await page.goto(url, wait_until="domcontentloaded", timeout=TIMEOUT_MS)
        await page.wait_for_selector(".video-card, .bili-video-card", timeout=TIMEOUT_MS)
        cards = await page.query_selector_all(".video-card, .bili-video-card")
        items = []
        for card in cards[:MAX_ITEMS]:
            link_el = await card.query_selector("a[href*='/video/']")
            title_el = await card.query_selector(".video-title, .title")
            desc_el = await card.query_selector(".video-desc, .desc")
            if not link_el or not title_el:
                continue
            href = await link_el.get_attribute("href") or ""
            if href.startswith("//"):
                href = "https:" + href
            elif href.startswith("/"):
                href = "https://www.bilibili.com" + href
            title = clean(await title_el.inner_text())
            if not title:
                continue
            items.append({
                "platform": "bilibili",
                "title": title,
                "summary": clean(await desc_el.inner_text()) if desc_el else "",
                "url": href,
            })
        return items
    finally:
        await context.close()


async def search_csdn(keyword: str, browser):
    context, page = await new_page(browser)
    try:
        url = f"https://so.csdn.net/so/search?q={quote(keyword)}"
        await page.goto(url, wait_until="domcontentloaded", timeout=TIMEOUT_MS)
        await page.wait_for_selector(".article-h1 a, .blog-card-box", timeout=TIMEOUT_MS)
        cards = await page.query_selector_all("article, .blog-item, .blog-card-box")
        items = []
        for card in cards[:MAX_ITEMS]:
            link_el = await card.query_selector("a[href*='blog.csdn.net']")
            if not link_el:
                continue
            title = clean(await link_el.inner_text())
            if len(title) < 4:
                continue
            href = await link_el.get_attribute("href")
            items.append({"platform": "csdn", "title": title, "summary": "", "url": href})
        return items
    finally:
        await context.close()


async def search_douyin(keyword: str, browser):
    """抖音搜索页需要登录态，未登录时通常拿不到结果，失败即返回空由上层降级。"""
    context, page = await new_page(browser)
    try:
        url = f"https://www.douyin.com/search/{quote(keyword)}?type=general"
        await page.goto(url, wait_until="domcontentloaded", timeout=TIMEOUT_MS)
        await page.wait_for_selector('[data-e2e="scroll-list"] a, .search-result-card', timeout=TIMEOUT_MS)
        cards = await page.query_selector_all('.search-result-card, [data-e2e="scroll-list"] li')
        items = []
        for card in cards[:MAX_ITEMS]:
            link_el = await card.query_selector("a[href*='/video/'], a[href]")
            title_el = await card.query_selector('[data-e2e="search-card-title"], .bdtm-cell')
            if not link_el:
                continue
            href = await link_el.get_attribute("href") or ""
            if href.startswith("/"):
                href = "https://www.douyin.com" + href
            title = clean(await title_el.inner_text()) if title_el else f"{keyword} 相关视频"
            if not title:
                continue
            items.append({"platform": "douyin", "title": title, "summary": "", "url": href})
        return items
    finally:
        await context.close()


async def run_search(keyword: str):
    results = []
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True, args=["--disable-blink-features=AutomationControlled"])
        try:
            tasks = [search_bilibili(keyword, browser), search_csdn(keyword, browser), search_douyin(keyword, browser)]
            for coro in asyncio.as_completed(tasks):
                try:
                    results.extend(await coro)
                except Exception:
                    pass
        finally:
            await browser.close()
    return results


@app.get("/search")
async def search(keyword: str = "Java"):
    keyword = (keyword or "").strip()
    if not keyword:
        return {"keyword": keyword, "count": 0, "references": []}
    try:
        refs = await run_search(keyword)
    except Exception as error:
        return {"keyword": keyword, "count": 0, "references": [], "error": str(error)}
    return {"keyword": keyword, "count": len(refs), "references": refs}


@app.get("/health")
async def health():
    return {"status": "up"}
